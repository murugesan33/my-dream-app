import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class MockApiService {

  constructor(private http: HttpClient) { }
  getUserDetails() {
    return {
      id: "1",
      fullname: "mmm",
      username: "mmm hhhh",
      password: "xsdsd",
      email: "xyz@ymail.com",
      address:"r/t middle street"
    };
  }

  setUserDetails(arr) {
    return {
      id: "1",
      fullname: "mmm",
      username: "mmm hhhh",
      password: "xsdsd",
      email: "xyz@ymail.com",
      address:"r/t middle street"
    };
  }

  setPetDetails(arr) {
    return {
      id:"1",
      userid:"12",
      name: "name",
      gender: "1",
      age: "1",
      address : "4/405 Perumal Koil Street",
      image:"img.png"
    };
  }

  getPetDetails() {
    return {
      id:"1",
      userid:"12",
      name: "name",
      gender: "1",
      age: "1",
      address : "4/405 Perumal Koil Street",
      image:"img.png"
    };
  }

  setUserPetsLists(arr) {
    return {
      id:"1",
      petId:"2",
      userId:"3",
    };
  }
    getUserPetsLists(){
      return {
        id:"1",
      petId:"2",
      userId:"3",
      };
    }

  
  }
