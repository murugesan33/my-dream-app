import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {ApiService, userPetLists, checkOut} from '../api.service';
import {Router} from '@angular/router';
import { ThrowStmt } from '@angular/compiler';
//import { EventEmitter } from 'events';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  @Input('products') products = [];
  @Input('title') title:string = '';
  @Input('status') status:boolean = false;
  @Output('productId')productId: EventEmitter<Number> = new EventEmitter();
  // public  arrItem = [];
  // public logKey = this.api.log.value;
  // public userId = this.api.uId.value;
  constructor(private api: ApiService, private router: Router) {}

  ngOnInit() { }

  buyProduct(id){
    this.productId.emit(id);
 }

}
