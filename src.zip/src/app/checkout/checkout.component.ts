import { Component, OnInit } from '@angular/core';
import {ApiService,userPetLists} from '../api.service';
import {Router} from '@angular/router';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  public arrObjectItem = [];
  public arrItem = [];
  quantity=1;
  quantityformcontrol:FormControl;
  constructor(private api:ApiService, private router: Router) { 
    if(!this.api.log.value){
      this.api.err.next("Please Login!");
      this.router.navigate(['login']);
     }else{
      this.api.err.next("");
      this.arrItem =((this.api.productItem.value.length > 0) ? this.api.productItem.value : JSON.parse(sessionStorage.getItem('products')));
     }
  }

  ngOnInit() {
      this.getCheckOutList();
      this.quantityformcontrol=new FormControl();

  }

  getCheckOutList(){
    if(this.arrItem!=null){
      this.api.getPetDetails().subscribe(data=>{
          for(let item of data){
              for(let it of this.arrItem){
                if(it.id == item.id){
                  item['quantity'] = it.Quantity;
                  this.arrObjectItem.push(item)
                }
              }
          }
      })
    }
  }

  deleteProduct(id){
    let filteredItems  = this.arrItem.filter((item) => item.id != id );
    sessionStorage.setItem('products',JSON.stringify(filteredItems));
    sessionStorage.setItem('item',JSON.stringify(filteredItems.length));
    this.api.productItem.next(filteredItems);
    this.api.item.next(filteredItems.length);
    this.arrItem = filteredItems;
    this.arrObjectItem = [];
    this.getCheckOutList();
  }

  checkOutData(){
    let status = false;
    const userId = (this.api.uId.value) ? this.api.uId.value : localStorage.getItem('userId');
    console.log(this.arrItem);
    console.log(this.arrObjectItem);
/*const postobj={
  "userId": userId,
  checoutLIst:this.arrObjectItem
}*/
   
  for(let item of this.arrItem){
       let arrItem = {
         petId:item.id,
         userId:userId,
         quantity:item.Quantity
       }
      this.api.setUserPetsLists(arrItem).subscribe(data => {
          status = true;
      });
    }
    setTimeout((status)=> {
      this.arrObjectItem = [];
      this.arrItem =[];
      sessionStorage.clear();
      this.api.productItem.next([]);
      this.api.item.next(0);
      this.router.navigate(['home']);
    }, 5000);
  }

}
