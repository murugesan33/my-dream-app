import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mypets',
  templateUrl: './mypets.component.html',
  styleUrls: ['./mypets.component.css']
})
export class MypetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
